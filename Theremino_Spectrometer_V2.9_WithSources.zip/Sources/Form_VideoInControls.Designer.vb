﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_VideoInControls
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_VideoInControls))
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker3 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems3 As cBlendItems = New cBlendItems
        Dim CBlendItems4 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker4 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker5 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems5 As cBlendItems = New cBlendItems
        Dim CBlendItems6 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker6 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker7 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems7 As cBlendItems = New cBlendItems
        Dim CBlendItems8 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker8 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker9 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems9 As cBlendItems = New cBlendItems
        Dim CBlendItems10 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker10 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker11 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems11 As cBlendItems = New cBlendItems
        Dim CBlendItems12 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker12 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker13 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems13 As cBlendItems = New cBlendItems
        Dim CBlendItems14 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker14 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker15 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems15 As cBlendItems = New cBlendItems
        Dim CBlendItems16 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker16 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker17 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems17 As cBlendItems = New cBlendItems
        Dim CBlendItems18 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker18 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker19 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems19 As cBlendItems = New cBlendItems
        Dim CBlendItems20 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker20 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker21 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems21 As cBlendItems = New cBlendItems
        Dim CBlendItems22 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker22 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker23 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems23 As cBlendItems = New cBlendItems
        Dim CBlendItems24 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker24 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker25 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems25 As cBlendItems = New cBlendItems
        Dim CBlendItems26 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker26 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker27 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems27 As cBlendItems = New cBlendItems
        Dim CBlendItems28 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker28 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker29 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems29 As cBlendItems = New cBlendItems
        Dim CBlendItems30 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker30 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker31 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems31 As cBlendItems = New cBlendItems
        Dim CBlendItems32 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker32 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker33 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems33 As cBlendItems = New cBlendItems
        Dim CBlendItems34 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker34 As DesignerRectTracker = New DesignerRectTracker
        Me.btn_Close = New MyButton
        Me.TrackBar_Brightness = New System.Windows.Forms.TrackBar
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.Tool_OpenSourcePanel = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.Tool_OpenFormatPanel = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.TrackBar_Contrast = New System.Windows.Forms.TrackBar
        Me.TrackBar_Gamma = New System.Windows.Forms.TrackBar
        Me.Label_Brightness = New System.Windows.Forms.Label
        Me.Label_Contrast = New System.Windows.Forms.Label
        Me.Label_Saturation = New System.Windows.Forms.Label
        Me.Label_Exposure = New System.Windows.Forms.Label
        Me.Label_WhiteBalance = New System.Windows.Forms.Label
        Me.Label_Gamma = New System.Windows.Forms.Label
        Me.TrackBar_Exposure = New System.Windows.Forms.TrackBar
        Me.TrackBar_WhiteBalance = New System.Windows.Forms.TrackBar
        Me.TrackBar_Saturation = New System.Windows.Forms.TrackBar
        Me.Label_Sharpness = New System.Windows.Forms.Label
        Me.TrackBar_Sharpness = New System.Windows.Forms.TrackBar
        Me.Label_Zoom = New System.Windows.Forms.Label
        Me.TrackBar_Zoom = New System.Windows.Forms.TrackBar
        Me.Label_Pan = New System.Windows.Forms.Label
        Me.TrackBar_Pan = New System.Windows.Forms.TrackBar
        Me.Label_Tilt = New System.Windows.Forms.Label
        Me.TrackBar_Tilt = New System.Windows.Forms.TrackBar
        Me.Label_Hue = New System.Windows.Forms.Label
        Me.TrackBar_Hue = New System.Windows.Forms.TrackBar
        Me.MyButton_Exposure = New MyButton
        Me.MyButton_Brightness = New MyButton
        Me.MyButton_Contrast = New MyButton
        Me.MyButton_Gamma = New MyButton
        Me.MyButton_Saturation = New MyButton
        Me.MyButton_WhiteBalance = New MyButton
        Me.MyButton_Hue = New MyButton
        Me.MyButton_Sharpness = New MyButton
        Me.MyButton_Zoom = New MyButton
        Me.MyButton_Pan = New MyButton
        Me.MyButton_Tilt = New MyButton
        Me.Label_Default = New System.Windows.Forms.Label
        Me.CheckBox_Exposure = New System.Windows.Forms.CheckBox
        Me.Label_Auto = New System.Windows.Forms.Label
        Me.CheckBox_Brightness = New System.Windows.Forms.CheckBox
        Me.CheckBox_Contrast = New System.Windows.Forms.CheckBox
        Me.CheckBox_Gamma = New System.Windows.Forms.CheckBox
        Me.CheckBox_Saturation = New System.Windows.Forms.CheckBox
        Me.CheckBox_WhiteBalance = New System.Windows.Forms.CheckBox
        Me.CheckBox_Hue = New System.Windows.Forms.CheckBox
        Me.CheckBox_Sharpness = New System.Windows.Forms.CheckBox
        Me.CheckBox_Zoom = New System.Windows.Forms.CheckBox
        Me.CheckBox_Pan = New System.Windows.Forms.CheckBox
        Me.CheckBox_Tilt = New System.Windows.Forms.CheckBox
        Me.ComboBox_VideoFormat = New MyComboBox
        Me.ComboBox_VideoSize = New MyComboBox
        Me.ComboBox_VideoFPS = New MyComboBox
        Me.Label_Compression = New System.Windows.Forms.Label
        Me.Label_VideoSize = New System.Windows.Forms.Label
        Me.Label_MaxFps = New System.Windows.Forms.Label
        Me.btn_DefaultAll = New MyButton
        Me.TrackBar_Focus = New System.Windows.Forms.TrackBar
        Me.CheckBox_Focus = New System.Windows.Forms.CheckBox
        Me.Label_Focus = New System.Windows.Forms.Label
        Me.CheckBox_Gain = New System.Windows.Forms.CheckBox
        Me.MyButton_Gain = New MyButton
        Me.Label_Gain = New System.Windows.Forms.Label
        Me.TrackBar_BackLight = New System.Windows.Forms.TrackBar
        Me.TrackBar_ColorEnable = New System.Windows.Forms.TrackBar
        Me.CheckBox_ColorEnable = New System.Windows.Forms.CheckBox
        Me.CheckBox_BackLight = New System.Windows.Forms.CheckBox
        Me.MyButton_ColorEnable = New MyButton
        Me.MyButton_BackLight = New MyButton
        Me.Label_ColorEnable = New System.Windows.Forms.Label
        Me.Label_BackLight = New System.Windows.Forms.Label
        Me.TrackBar_Gain = New System.Windows.Forms.TrackBar
        Me.MyButton_Focus = New MyButton
        CType(Me.TrackBar_Brightness, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.TrackBar_Contrast, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Gamma, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Exposure, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_WhiteBalance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Saturation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Sharpness, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Zoom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Pan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Tilt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Hue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Focus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_BackLight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_ColorEnable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Gain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_Close
        '
        Me.btn_Close.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Close.BorderShow = False
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Close.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Close.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems2.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_Close.ColorFillBlendChecked = CBlendItems2
        Me.btn_Close.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Close.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Close.Corners.All = CType(6, Short)
        Me.btn_Close.Corners.LowerLeft = CType(6, Short)
        Me.btn_Close.Corners.LowerRight = CType(6, Short)
        Me.btn_Close.Corners.UpperLeft = CType(6, Short)
        Me.btn_Close.Corners.UpperRight = CType(6, Short)
        Me.btn_Close.DimFactorOver = 30
        Me.btn_Close.FillType = MyButton.eFillType.LinearVertical
        Me.btn_Close.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.btn_Close.FocalPoints.CenterPtX = 0.3787879!
        Me.btn_Close.FocalPoints.CenterPtY = 0.3181818!
        Me.btn_Close.FocalPoints.FocusPtX = 0.0!
        Me.btn_Close.FocalPoints.FocusPtY = 0.0!
        Me.btn_Close.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_Close.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_Close.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Close.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Close.FocusPtTracker = DesignerRectTracker2
        Me.btn_Close.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Close.Image = Nothing
        Me.btn_Close.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Close.ImageIndex = 0
        Me.btn_Close.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Close.Location = New System.Drawing.Point(148, 535)
        Me.btn_Close.Name = "btn_Close"
        Me.btn_Close.Shape = MyButton.eShape.Rectangle
        Me.btn_Close.SideImage = Nothing
        Me.btn_Close.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Close.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_Close.Size = New System.Drawing.Size(104, 22)
        Me.btn_Close.TabIndex = 71
        Me.btn_Close.TabStop = False
        Me.btn_Close.Text = "Close"
        Me.btn_Close.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Close.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_Close.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Close.TextShadow = System.Drawing.Color.Transparent
        '
        'TrackBar_Brightness
        '
        Me.TrackBar_Brightness.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Brightness.AutoSize = False
        Me.TrackBar_Brightness.Location = New System.Drawing.Point(72, 157)
        Me.TrackBar_Brightness.Maximum = 255
        Me.TrackBar_Brightness.Name = "TrackBar_Brightness"
        Me.TrackBar_Brightness.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Brightness.TabIndex = 3
        Me.TrackBar_Brightness.TickFrequency = 20
        Me.TrackBar_Brightness.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator2, Me.Tool_OpenSourcePanel, Me.ToolStripSeparator1, Me.Tool_OpenFormatPanel, Me.ToolStripSeparator3})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(261, 36)
        Me.ToolStrip1.TabIndex = 73
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 36)
        '
        'Tool_OpenSourcePanel
        '
        Me.Tool_OpenSourcePanel.Image = CType(resources.GetObject("Tool_OpenSourcePanel.Image"), System.Drawing.Image)
        Me.Tool_OpenSourcePanel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Tool_OpenSourcePanel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_OpenSourcePanel.Name = "Tool_OpenSourcePanel"
        Me.Tool_OpenSourcePanel.Size = New System.Drawing.Size(102, 33)
        Me.Tool_OpenSourcePanel.Text = "Open Source Panel"
        Me.Tool_OpenSourcePanel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 36)
        '
        'Tool_OpenFormatPanel
        '
        Me.Tool_OpenFormatPanel.Image = CType(resources.GetObject("Tool_OpenFormatPanel.Image"), System.Drawing.Image)
        Me.Tool_OpenFormatPanel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Tool_OpenFormatPanel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_OpenFormatPanel.Name = "Tool_OpenFormatPanel"
        Me.Tool_OpenFormatPanel.Size = New System.Drawing.Size(103, 33)
        Me.Tool_OpenFormatPanel.Text = "Open Format Panel"
        Me.Tool_OpenFormatPanel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 36)
        '
        'TrackBar_Contrast
        '
        Me.TrackBar_Contrast.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Contrast.AutoSize = False
        Me.TrackBar_Contrast.Location = New System.Drawing.Point(72, 184)
        Me.TrackBar_Contrast.Maximum = 255
        Me.TrackBar_Contrast.Name = "TrackBar_Contrast"
        Me.TrackBar_Contrast.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Contrast.TabIndex = 4
        Me.TrackBar_Contrast.TickFrequency = 20
        Me.TrackBar_Contrast.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'TrackBar_Gamma
        '
        Me.TrackBar_Gamma.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Gamma.AutoSize = False
        Me.TrackBar_Gamma.Location = New System.Drawing.Point(72, 211)
        Me.TrackBar_Gamma.Maximum = 255
        Me.TrackBar_Gamma.Name = "TrackBar_Gamma"
        Me.TrackBar_Gamma.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Gamma.TabIndex = 5
        Me.TrackBar_Gamma.TickFrequency = 20
        Me.TrackBar_Gamma.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'Label_Brightness
        '
        Me.Label_Brightness.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Brightness.BackColor = System.Drawing.Color.MintCream
        Me.Label_Brightness.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Brightness.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Brightness.Location = New System.Drawing.Point(216, 165)
        Me.Label_Brightness.Name = "Label_Brightness"
        Me.Label_Brightness.Size = New System.Drawing.Size(35, 20)
        Me.Label_Brightness.TabIndex = 78
        Me.Label_Brightness.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Contrast
        '
        Me.Label_Contrast.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Contrast.BackColor = System.Drawing.Color.MintCream
        Me.Label_Contrast.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Contrast.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Contrast.Location = New System.Drawing.Point(216, 192)
        Me.Label_Contrast.Name = "Label_Contrast"
        Me.Label_Contrast.Size = New System.Drawing.Size(35, 20)
        Me.Label_Contrast.TabIndex = 79
        Me.Label_Contrast.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Saturation
        '
        Me.Label_Saturation.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Saturation.BackColor = System.Drawing.Color.MintCream
        Me.Label_Saturation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Saturation.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Saturation.Location = New System.Drawing.Point(216, 277)
        Me.Label_Saturation.Name = "Label_Saturation"
        Me.Label_Saturation.Size = New System.Drawing.Size(35, 20)
        Me.Label_Saturation.TabIndex = 80
        Me.Label_Saturation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Exposure
        '
        Me.Label_Exposure.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Exposure.BackColor = System.Drawing.Color.MintCream
        Me.Label_Exposure.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Exposure.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Exposure.Location = New System.Drawing.Point(216, 111)
        Me.Label_Exposure.Name = "Label_Exposure"
        Me.Label_Exposure.Size = New System.Drawing.Size(35, 20)
        Me.Label_Exposure.TabIndex = 89
        Me.Label_Exposure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_WhiteBalance
        '
        Me.Label_WhiteBalance.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_WhiteBalance.BackColor = System.Drawing.Color.MintCream
        Me.Label_WhiteBalance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_WhiteBalance.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_WhiteBalance.Location = New System.Drawing.Point(216, 303)
        Me.Label_WhiteBalance.Name = "Label_WhiteBalance"
        Me.Label_WhiteBalance.Size = New System.Drawing.Size(35, 20)
        Me.Label_WhiteBalance.TabIndex = 88
        Me.Label_WhiteBalance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Gamma
        '
        Me.Label_Gamma.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Gamma.BackColor = System.Drawing.Color.MintCream
        Me.Label_Gamma.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Gamma.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Gamma.Location = New System.Drawing.Point(216, 220)
        Me.Label_Gamma.Name = "Label_Gamma"
        Me.Label_Gamma.Size = New System.Drawing.Size(35, 20)
        Me.Label_Gamma.TabIndex = 87
        Me.Label_Gamma.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_Exposure
        '
        Me.TrackBar_Exposure.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Exposure.AutoSize = False
        Me.TrackBar_Exposure.Location = New System.Drawing.Point(72, 103)
        Me.TrackBar_Exposure.Maximum = 255
        Me.TrackBar_Exposure.Name = "TrackBar_Exposure"
        Me.TrackBar_Exposure.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Exposure.TabIndex = 1
        Me.TrackBar_Exposure.TickFrequency = 20
        Me.TrackBar_Exposure.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'TrackBar_WhiteBalance
        '
        Me.TrackBar_WhiteBalance.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_WhiteBalance.AutoSize = False
        Me.TrackBar_WhiteBalance.Location = New System.Drawing.Point(72, 294)
        Me.TrackBar_WhiteBalance.Maximum = 255
        Me.TrackBar_WhiteBalance.Name = "TrackBar_WhiteBalance"
        Me.TrackBar_WhiteBalance.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_WhiteBalance.TabIndex = 8
        Me.TrackBar_WhiteBalance.TickFrequency = 20
        Me.TrackBar_WhiteBalance.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'TrackBar_Saturation
        '
        Me.TrackBar_Saturation.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Saturation.AutoSize = False
        Me.TrackBar_Saturation.Location = New System.Drawing.Point(72, 268)
        Me.TrackBar_Saturation.Maximum = 255
        Me.TrackBar_Saturation.Name = "TrackBar_Saturation"
        Me.TrackBar_Saturation.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Saturation.TabIndex = 7
        Me.TrackBar_Saturation.TickFrequency = 20
        Me.TrackBar_Saturation.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'Label_Sharpness
        '
        Me.Label_Sharpness.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Sharpness.BackColor = System.Drawing.Color.MintCream
        Me.Label_Sharpness.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Sharpness.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Sharpness.Location = New System.Drawing.Point(216, 475)
        Me.Label_Sharpness.Name = "Label_Sharpness"
        Me.Label_Sharpness.Size = New System.Drawing.Size(35, 20)
        Me.Label_Sharpness.TabIndex = 93
        Me.Label_Sharpness.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_Sharpness
        '
        Me.TrackBar_Sharpness.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Sharpness.AutoSize = False
        Me.TrackBar_Sharpness.Location = New System.Drawing.Point(72, 466)
        Me.TrackBar_Sharpness.Maximum = 255
        Me.TrackBar_Sharpness.Name = "TrackBar_Sharpness"
        Me.TrackBar_Sharpness.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Sharpness.TabIndex = 14
        Me.TrackBar_Sharpness.TickFrequency = 20
        Me.TrackBar_Sharpness.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'Label_Zoom
        '
        Me.Label_Zoom.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Zoom.BackColor = System.Drawing.Color.MintCream
        Me.Label_Zoom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Zoom.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Zoom.Location = New System.Drawing.Point(216, 390)
        Me.Label_Zoom.Name = "Label_Zoom"
        Me.Label_Zoom.Size = New System.Drawing.Size(35, 20)
        Me.Label_Zoom.TabIndex = 97
        Me.Label_Zoom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_Zoom
        '
        Me.TrackBar_Zoom.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Zoom.AutoSize = False
        Me.TrackBar_Zoom.Location = New System.Drawing.Point(72, 380)
        Me.TrackBar_Zoom.Maximum = 255
        Me.TrackBar_Zoom.Name = "TrackBar_Zoom"
        Me.TrackBar_Zoom.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Zoom.TabIndex = 11
        Me.TrackBar_Zoom.TickFrequency = 20
        Me.TrackBar_Zoom.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'Label_Pan
        '
        Me.Label_Pan.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Pan.BackColor = System.Drawing.Color.MintCream
        Me.Label_Pan.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Pan.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Pan.Location = New System.Drawing.Point(216, 416)
        Me.Label_Pan.Name = "Label_Pan"
        Me.Label_Pan.Size = New System.Drawing.Size(35, 20)
        Me.Label_Pan.TabIndex = 100
        Me.Label_Pan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_Pan
        '
        Me.TrackBar_Pan.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Pan.AutoSize = False
        Me.TrackBar_Pan.Location = New System.Drawing.Point(72, 407)
        Me.TrackBar_Pan.Maximum = 255
        Me.TrackBar_Pan.Name = "TrackBar_Pan"
        Me.TrackBar_Pan.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Pan.TabIndex = 12
        Me.TrackBar_Pan.TickFrequency = 20
        Me.TrackBar_Pan.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'Label_Tilt
        '
        Me.Label_Tilt.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Tilt.BackColor = System.Drawing.Color.MintCream
        Me.Label_Tilt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Tilt.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Tilt.Location = New System.Drawing.Point(216, 443)
        Me.Label_Tilt.Name = "Label_Tilt"
        Me.Label_Tilt.Size = New System.Drawing.Size(35, 20)
        Me.Label_Tilt.TabIndex = 103
        Me.Label_Tilt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_Tilt
        '
        Me.TrackBar_Tilt.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Tilt.AutoSize = False
        Me.TrackBar_Tilt.Location = New System.Drawing.Point(72, 434)
        Me.TrackBar_Tilt.Maximum = 255
        Me.TrackBar_Tilt.Name = "TrackBar_Tilt"
        Me.TrackBar_Tilt.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Tilt.TabIndex = 13
        Me.TrackBar_Tilt.TickFrequency = 20
        Me.TrackBar_Tilt.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'Label_Hue
        '
        Me.Label_Hue.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Hue.BackColor = System.Drawing.Color.MintCream
        Me.Label_Hue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Hue.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Hue.Location = New System.Drawing.Point(216, 329)
        Me.Label_Hue.Name = "Label_Hue"
        Me.Label_Hue.Size = New System.Drawing.Size(35, 20)
        Me.Label_Hue.TabIndex = 106
        Me.Label_Hue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_Hue
        '
        Me.TrackBar_Hue.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Hue.AutoSize = False
        Me.TrackBar_Hue.Location = New System.Drawing.Point(72, 321)
        Me.TrackBar_Hue.Maximum = 255
        Me.TrackBar_Hue.Name = "TrackBar_Hue"
        Me.TrackBar_Hue.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Hue.TabIndex = 9
        Me.TrackBar_Hue.TickFrequency = 20
        Me.TrackBar_Hue.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'MyButton_Exposure
        '
        Me.MyButton_Exposure.BorderShow = False
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Exposure.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Exposure.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems4.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Exposure.ColorFillBlendChecked = CBlendItems4
        Me.MyButton_Exposure.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Exposure.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Exposure.Corners.All = CType(-1, Short)
        Me.MyButton_Exposure.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Exposure.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Exposure.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Exposure.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Exposure.DimFactorOver = -40
        Me.MyButton_Exposure.FillType = MyButton.eFillType.Solid
        Me.MyButton_Exposure.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Exposure.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Exposure.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Exposure.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Exposure.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Exposure.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Exposure.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Exposure.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Exposure.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Exposure.FocusPtTracker = DesignerRectTracker4
        Me.MyButton_Exposure.Image = Nothing
        Me.MyButton_Exposure.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Exposure.ImageIndex = 0
        Me.MyButton_Exposure.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Exposure.Location = New System.Drawing.Point(7, 109)
        Me.MyButton_Exposure.Name = "MyButton_Exposure"
        Me.MyButton_Exposure.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Exposure.SideImage = CType(resources.GetObject("MyButton_Exposure.SideImage"), System.Drawing.Image)
        Me.MyButton_Exposure.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Exposure.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Exposure.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Exposure.TabIndex = 107
        Me.MyButton_Exposure.TabStop = False
        Me.MyButton_Exposure.Text = ""
        Me.MyButton_Exposure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Exposure.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Exposure.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Exposure.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_Brightness
        '
        Me.MyButton_Brightness.BorderShow = False
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Brightness.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Brightness.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems6.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Brightness.ColorFillBlendChecked = CBlendItems6
        Me.MyButton_Brightness.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Brightness.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Brightness.Corners.All = CType(-1, Short)
        Me.MyButton_Brightness.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Brightness.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Brightness.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Brightness.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Brightness.DimFactorOver = -40
        Me.MyButton_Brightness.FillType = MyButton.eFillType.Solid
        Me.MyButton_Brightness.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Brightness.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Brightness.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Brightness.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Brightness.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Brightness.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Brightness.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Brightness.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Brightness.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Brightness.FocusPtTracker = DesignerRectTracker6
        Me.MyButton_Brightness.Image = Nothing
        Me.MyButton_Brightness.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Brightness.ImageIndex = 0
        Me.MyButton_Brightness.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Brightness.Location = New System.Drawing.Point(7, 163)
        Me.MyButton_Brightness.Name = "MyButton_Brightness"
        Me.MyButton_Brightness.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Brightness.SideImage = CType(resources.GetObject("MyButton_Brightness.SideImage"), System.Drawing.Image)
        Me.MyButton_Brightness.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Brightness.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Brightness.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Brightness.TabIndex = 108
        Me.MyButton_Brightness.TabStop = False
        Me.MyButton_Brightness.Text = ""
        Me.MyButton_Brightness.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Brightness.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Brightness.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Brightness.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_Contrast
        '
        Me.MyButton_Contrast.BorderShow = False
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Contrast.CenterPtTracker = DesignerRectTracker7
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Contrast.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems8.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Contrast.ColorFillBlendChecked = CBlendItems8
        Me.MyButton_Contrast.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Contrast.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Contrast.Corners.All = CType(-1, Short)
        Me.MyButton_Contrast.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Contrast.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Contrast.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Contrast.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Contrast.DimFactorOver = -40
        Me.MyButton_Contrast.FillType = MyButton.eFillType.Solid
        Me.MyButton_Contrast.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Contrast.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Contrast.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Contrast.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Contrast.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Contrast.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Contrast.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Contrast.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Contrast.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Contrast.FocusPtTracker = DesignerRectTracker8
        Me.MyButton_Contrast.Image = Nothing
        Me.MyButton_Contrast.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Contrast.ImageIndex = 0
        Me.MyButton_Contrast.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Contrast.Location = New System.Drawing.Point(7, 190)
        Me.MyButton_Contrast.Name = "MyButton_Contrast"
        Me.MyButton_Contrast.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Contrast.SideImage = CType(resources.GetObject("MyButton_Contrast.SideImage"), System.Drawing.Image)
        Me.MyButton_Contrast.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Contrast.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Contrast.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Contrast.TabIndex = 109
        Me.MyButton_Contrast.TabStop = False
        Me.MyButton_Contrast.Text = ""
        Me.MyButton_Contrast.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Contrast.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Contrast.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Contrast.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_Gamma
        '
        Me.MyButton_Gamma.BorderShow = False
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Gamma.CenterPtTracker = DesignerRectTracker9
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Gamma.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems10.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Gamma.ColorFillBlendChecked = CBlendItems10
        Me.MyButton_Gamma.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Gamma.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Gamma.Corners.All = CType(-1, Short)
        Me.MyButton_Gamma.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Gamma.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Gamma.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Gamma.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Gamma.DimFactorOver = -40
        Me.MyButton_Gamma.FillType = MyButton.eFillType.Solid
        Me.MyButton_Gamma.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Gamma.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Gamma.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Gamma.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Gamma.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Gamma.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Gamma.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Gamma.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Gamma.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Gamma.FocusPtTracker = DesignerRectTracker10
        Me.MyButton_Gamma.Image = Nothing
        Me.MyButton_Gamma.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Gamma.ImageIndex = 0
        Me.MyButton_Gamma.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Gamma.Location = New System.Drawing.Point(7, 217)
        Me.MyButton_Gamma.Name = "MyButton_Gamma"
        Me.MyButton_Gamma.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Gamma.SideImage = CType(resources.GetObject("MyButton_Gamma.SideImage"), System.Drawing.Image)
        Me.MyButton_Gamma.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Gamma.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Gamma.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Gamma.TabIndex = 110
        Me.MyButton_Gamma.TabStop = False
        Me.MyButton_Gamma.Text = ""
        Me.MyButton_Gamma.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Gamma.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Gamma.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Gamma.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_Saturation
        '
        Me.MyButton_Saturation.BorderShow = False
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Saturation.CenterPtTracker = DesignerRectTracker11
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Saturation.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems12.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Saturation.ColorFillBlendChecked = CBlendItems12
        Me.MyButton_Saturation.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Saturation.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Saturation.Corners.All = CType(-1, Short)
        Me.MyButton_Saturation.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Saturation.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Saturation.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Saturation.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Saturation.DimFactorOver = -40
        Me.MyButton_Saturation.FillType = MyButton.eFillType.Solid
        Me.MyButton_Saturation.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Saturation.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Saturation.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Saturation.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Saturation.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Saturation.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Saturation.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Saturation.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Saturation.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Saturation.FocusPtTracker = DesignerRectTracker12
        Me.MyButton_Saturation.Image = Nothing
        Me.MyButton_Saturation.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Saturation.ImageIndex = 0
        Me.MyButton_Saturation.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Saturation.Location = New System.Drawing.Point(7, 274)
        Me.MyButton_Saturation.Name = "MyButton_Saturation"
        Me.MyButton_Saturation.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Saturation.SideImage = CType(resources.GetObject("MyButton_Saturation.SideImage"), System.Drawing.Image)
        Me.MyButton_Saturation.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Saturation.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Saturation.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Saturation.TabIndex = 111
        Me.MyButton_Saturation.TabStop = False
        Me.MyButton_Saturation.Text = ""
        Me.MyButton_Saturation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Saturation.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Saturation.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Saturation.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_WhiteBalance
        '
        Me.MyButton_WhiteBalance.BorderShow = False
        DesignerRectTracker13.IsActive = False
        DesignerRectTracker13.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker13.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_WhiteBalance.CenterPtTracker = DesignerRectTracker13
        CBlendItems13.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems13.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_WhiteBalance.ColorFillBlend = CBlendItems13
        CBlendItems14.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems14.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_WhiteBalance.ColorFillBlendChecked = CBlendItems14
        Me.MyButton_WhiteBalance.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_WhiteBalance.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_WhiteBalance.Corners.All = CType(-1, Short)
        Me.MyButton_WhiteBalance.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_WhiteBalance.Corners.LowerRight = CType(11, Short)
        Me.MyButton_WhiteBalance.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_WhiteBalance.Corners.UpperRight = CType(11, Short)
        Me.MyButton_WhiteBalance.DimFactorOver = -40
        Me.MyButton_WhiteBalance.FillType = MyButton.eFillType.Solid
        Me.MyButton_WhiteBalance.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_WhiteBalance.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_WhiteBalance.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_WhiteBalance.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_WhiteBalance.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_WhiteBalance.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_WhiteBalance.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_WhiteBalance.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_WhiteBalance.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker14.IsActive = False
        DesignerRectTracker14.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker14.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_WhiteBalance.FocusPtTracker = DesignerRectTracker14
        Me.MyButton_WhiteBalance.Image = Nothing
        Me.MyButton_WhiteBalance.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_WhiteBalance.ImageIndex = 0
        Me.MyButton_WhiteBalance.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_WhiteBalance.Location = New System.Drawing.Point(7, 301)
        Me.MyButton_WhiteBalance.Name = "MyButton_WhiteBalance"
        Me.MyButton_WhiteBalance.Shape = MyButton.eShape.Rectangle
        Me.MyButton_WhiteBalance.SideImage = CType(resources.GetObject("MyButton_WhiteBalance.SideImage"), System.Drawing.Image)
        Me.MyButton_WhiteBalance.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_WhiteBalance.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_WhiteBalance.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_WhiteBalance.TabIndex = 112
        Me.MyButton_WhiteBalance.TabStop = False
        Me.MyButton_WhiteBalance.Text = ""
        Me.MyButton_WhiteBalance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_WhiteBalance.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_WhiteBalance.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_WhiteBalance.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_Hue
        '
        Me.MyButton_Hue.BorderShow = False
        DesignerRectTracker15.IsActive = False
        DesignerRectTracker15.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker15.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Hue.CenterPtTracker = DesignerRectTracker15
        CBlendItems15.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems15.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Hue.ColorFillBlend = CBlendItems15
        CBlendItems16.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems16.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Hue.ColorFillBlendChecked = CBlendItems16
        Me.MyButton_Hue.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Hue.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Hue.Corners.All = CType(-1, Short)
        Me.MyButton_Hue.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Hue.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Hue.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Hue.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Hue.DimFactorOver = -40
        Me.MyButton_Hue.FillType = MyButton.eFillType.Solid
        Me.MyButton_Hue.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Hue.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Hue.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Hue.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Hue.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Hue.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Hue.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Hue.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Hue.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker16.IsActive = False
        DesignerRectTracker16.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker16.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Hue.FocusPtTracker = DesignerRectTracker16
        Me.MyButton_Hue.Image = Nothing
        Me.MyButton_Hue.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Hue.ImageIndex = 0
        Me.MyButton_Hue.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Hue.Location = New System.Drawing.Point(7, 328)
        Me.MyButton_Hue.Name = "MyButton_Hue"
        Me.MyButton_Hue.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Hue.SideImage = CType(resources.GetObject("MyButton_Hue.SideImage"), System.Drawing.Image)
        Me.MyButton_Hue.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Hue.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Hue.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Hue.TabIndex = 113
        Me.MyButton_Hue.TabStop = False
        Me.MyButton_Hue.Text = ""
        Me.MyButton_Hue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Hue.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Hue.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Hue.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_Sharpness
        '
        Me.MyButton_Sharpness.BorderShow = False
        DesignerRectTracker17.IsActive = False
        DesignerRectTracker17.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker17.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Sharpness.CenterPtTracker = DesignerRectTracker17
        CBlendItems17.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems17.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Sharpness.ColorFillBlend = CBlendItems17
        CBlendItems18.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems18.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Sharpness.ColorFillBlendChecked = CBlendItems18
        Me.MyButton_Sharpness.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Sharpness.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Sharpness.Corners.All = CType(-1, Short)
        Me.MyButton_Sharpness.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Sharpness.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Sharpness.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Sharpness.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Sharpness.DimFactorOver = -40
        Me.MyButton_Sharpness.FillType = MyButton.eFillType.Solid
        Me.MyButton_Sharpness.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Sharpness.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Sharpness.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Sharpness.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Sharpness.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Sharpness.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Sharpness.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Sharpness.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Sharpness.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker18.IsActive = False
        DesignerRectTracker18.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker18.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Sharpness.FocusPtTracker = DesignerRectTracker18
        Me.MyButton_Sharpness.Image = Nothing
        Me.MyButton_Sharpness.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Sharpness.ImageIndex = 0
        Me.MyButton_Sharpness.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Sharpness.Location = New System.Drawing.Point(7, 473)
        Me.MyButton_Sharpness.Name = "MyButton_Sharpness"
        Me.MyButton_Sharpness.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Sharpness.SideImage = CType(resources.GetObject("MyButton_Sharpness.SideImage"), System.Drawing.Image)
        Me.MyButton_Sharpness.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Sharpness.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Sharpness.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Sharpness.TabIndex = 114
        Me.MyButton_Sharpness.TabStop = False
        Me.MyButton_Sharpness.Text = ""
        Me.MyButton_Sharpness.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Sharpness.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Sharpness.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Sharpness.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_Zoom
        '
        Me.MyButton_Zoom.BorderShow = False
        DesignerRectTracker19.IsActive = False
        DesignerRectTracker19.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker19.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Zoom.CenterPtTracker = DesignerRectTracker19
        CBlendItems19.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems19.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Zoom.ColorFillBlend = CBlendItems19
        CBlendItems20.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems20.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Zoom.ColorFillBlendChecked = CBlendItems20
        Me.MyButton_Zoom.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Zoom.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Zoom.Corners.All = CType(-1, Short)
        Me.MyButton_Zoom.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Zoom.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Zoom.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Zoom.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Zoom.DimFactorOver = -40
        Me.MyButton_Zoom.FillType = MyButton.eFillType.Solid
        Me.MyButton_Zoom.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Zoom.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Zoom.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Zoom.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Zoom.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Zoom.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Zoom.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Zoom.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Zoom.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker20.IsActive = False
        DesignerRectTracker20.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker20.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Zoom.FocusPtTracker = DesignerRectTracker20
        Me.MyButton_Zoom.Image = Nothing
        Me.MyButton_Zoom.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Zoom.ImageIndex = 0
        Me.MyButton_Zoom.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Zoom.Location = New System.Drawing.Point(7, 387)
        Me.MyButton_Zoom.Name = "MyButton_Zoom"
        Me.MyButton_Zoom.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Zoom.SideImage = CType(resources.GetObject("MyButton_Zoom.SideImage"), System.Drawing.Image)
        Me.MyButton_Zoom.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Zoom.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Zoom.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Zoom.TabIndex = 115
        Me.MyButton_Zoom.TabStop = False
        Me.MyButton_Zoom.Text = ""
        Me.MyButton_Zoom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Zoom.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Zoom.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Zoom.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_Pan
        '
        Me.MyButton_Pan.BorderShow = False
        DesignerRectTracker21.IsActive = False
        DesignerRectTracker21.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker21.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Pan.CenterPtTracker = DesignerRectTracker21
        CBlendItems21.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems21.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Pan.ColorFillBlend = CBlendItems21
        CBlendItems22.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems22.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Pan.ColorFillBlendChecked = CBlendItems22
        Me.MyButton_Pan.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Pan.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Pan.Corners.All = CType(-1, Short)
        Me.MyButton_Pan.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Pan.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Pan.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Pan.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Pan.DimFactorOver = -40
        Me.MyButton_Pan.FillType = MyButton.eFillType.Solid
        Me.MyButton_Pan.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Pan.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Pan.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Pan.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Pan.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Pan.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Pan.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Pan.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Pan.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker22.IsActive = False
        DesignerRectTracker22.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker22.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Pan.FocusPtTracker = DesignerRectTracker22
        Me.MyButton_Pan.Image = Nothing
        Me.MyButton_Pan.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Pan.ImageIndex = 0
        Me.MyButton_Pan.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Pan.Location = New System.Drawing.Point(7, 414)
        Me.MyButton_Pan.Name = "MyButton_Pan"
        Me.MyButton_Pan.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Pan.SideImage = CType(resources.GetObject("MyButton_Pan.SideImage"), System.Drawing.Image)
        Me.MyButton_Pan.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Pan.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Pan.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Pan.TabIndex = 116
        Me.MyButton_Pan.TabStop = False
        Me.MyButton_Pan.Text = ""
        Me.MyButton_Pan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Pan.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Pan.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Pan.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_Tilt
        '
        Me.MyButton_Tilt.BorderShow = False
        DesignerRectTracker23.IsActive = False
        DesignerRectTracker23.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker23.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Tilt.CenterPtTracker = DesignerRectTracker23
        CBlendItems23.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems23.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Tilt.ColorFillBlend = CBlendItems23
        CBlendItems24.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems24.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Tilt.ColorFillBlendChecked = CBlendItems24
        Me.MyButton_Tilt.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Tilt.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Tilt.Corners.All = CType(-1, Short)
        Me.MyButton_Tilt.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Tilt.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Tilt.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Tilt.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Tilt.DimFactorOver = -40
        Me.MyButton_Tilt.FillType = MyButton.eFillType.Solid
        Me.MyButton_Tilt.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Tilt.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Tilt.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Tilt.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Tilt.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Tilt.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Tilt.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Tilt.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Tilt.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker24.IsActive = False
        DesignerRectTracker24.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker24.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Tilt.FocusPtTracker = DesignerRectTracker24
        Me.MyButton_Tilt.Image = Nothing
        Me.MyButton_Tilt.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Tilt.ImageIndex = 0
        Me.MyButton_Tilt.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Tilt.Location = New System.Drawing.Point(7, 441)
        Me.MyButton_Tilt.Name = "MyButton_Tilt"
        Me.MyButton_Tilt.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Tilt.SideImage = CType(resources.GetObject("MyButton_Tilt.SideImage"), System.Drawing.Image)
        Me.MyButton_Tilt.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Tilt.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Tilt.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Tilt.TabIndex = 117
        Me.MyButton_Tilt.TabStop = False
        Me.MyButton_Tilt.Text = ""
        Me.MyButton_Tilt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Tilt.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Tilt.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Tilt.TextShadow = System.Drawing.Color.Transparent
        '
        'Label_Default
        '
        Me.Label_Default.AutoSize = True
        Me.Label_Default.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Default.Location = New System.Drawing.Point(6, 91)
        Me.Label_Default.Name = "Label_Default"
        Me.Label_Default.Size = New System.Drawing.Size(42, 13)
        Me.Label_Default.TabIndex = 118
        Me.Label_Default.Text = "Default"
        '
        'CheckBox_Exposure
        '
        Me.CheckBox_Exposure.AutoSize = True
        Me.CheckBox_Exposure.Location = New System.Drawing.Point(57, 116)
        Me.CheckBox_Exposure.Name = "CheckBox_Exposure"
        Me.CheckBox_Exposure.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Exposure.TabIndex = 119
        Me.CheckBox_Exposure.TabStop = False
        Me.CheckBox_Exposure.UseVisualStyleBackColor = True
        '
        'Label_Auto
        '
        Me.Label_Auto.AutoSize = True
        Me.Label_Auto.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Auto.Location = New System.Drawing.Point(48, 91)
        Me.Label_Auto.Name = "Label_Auto"
        Me.Label_Auto.Size = New System.Drawing.Size(30, 13)
        Me.Label_Auto.TabIndex = 120
        Me.Label_Auto.Text = "Auto"
        '
        'CheckBox_Brightness
        '
        Me.CheckBox_Brightness.AutoSize = True
        Me.CheckBox_Brightness.Location = New System.Drawing.Point(57, 170)
        Me.CheckBox_Brightness.Name = "CheckBox_Brightness"
        Me.CheckBox_Brightness.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Brightness.TabIndex = 121
        Me.CheckBox_Brightness.TabStop = False
        Me.CheckBox_Brightness.UseVisualStyleBackColor = True
        '
        'CheckBox_Contrast
        '
        Me.CheckBox_Contrast.AutoSize = True
        Me.CheckBox_Contrast.Location = New System.Drawing.Point(57, 197)
        Me.CheckBox_Contrast.Name = "CheckBox_Contrast"
        Me.CheckBox_Contrast.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Contrast.TabIndex = 122
        Me.CheckBox_Contrast.TabStop = False
        Me.CheckBox_Contrast.UseVisualStyleBackColor = True
        '
        'CheckBox_Gamma
        '
        Me.CheckBox_Gamma.AutoSize = True
        Me.CheckBox_Gamma.Location = New System.Drawing.Point(57, 224)
        Me.CheckBox_Gamma.Name = "CheckBox_Gamma"
        Me.CheckBox_Gamma.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Gamma.TabIndex = 123
        Me.CheckBox_Gamma.TabStop = False
        Me.CheckBox_Gamma.UseVisualStyleBackColor = True
        '
        'CheckBox_Saturation
        '
        Me.CheckBox_Saturation.AutoSize = True
        Me.CheckBox_Saturation.Location = New System.Drawing.Point(57, 281)
        Me.CheckBox_Saturation.Name = "CheckBox_Saturation"
        Me.CheckBox_Saturation.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Saturation.TabIndex = 124
        Me.CheckBox_Saturation.TabStop = False
        Me.CheckBox_Saturation.UseVisualStyleBackColor = True
        '
        'CheckBox_WhiteBalance
        '
        Me.CheckBox_WhiteBalance.AutoSize = True
        Me.CheckBox_WhiteBalance.Location = New System.Drawing.Point(57, 307)
        Me.CheckBox_WhiteBalance.Name = "CheckBox_WhiteBalance"
        Me.CheckBox_WhiteBalance.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_WhiteBalance.TabIndex = 125
        Me.CheckBox_WhiteBalance.TabStop = False
        Me.CheckBox_WhiteBalance.UseVisualStyleBackColor = True
        '
        'CheckBox_Hue
        '
        Me.CheckBox_Hue.AutoSize = True
        Me.CheckBox_Hue.Location = New System.Drawing.Point(57, 335)
        Me.CheckBox_Hue.Name = "CheckBox_Hue"
        Me.CheckBox_Hue.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Hue.TabIndex = 126
        Me.CheckBox_Hue.TabStop = False
        Me.CheckBox_Hue.UseVisualStyleBackColor = True
        '
        'CheckBox_Sharpness
        '
        Me.CheckBox_Sharpness.AutoSize = True
        Me.CheckBox_Sharpness.Location = New System.Drawing.Point(57, 480)
        Me.CheckBox_Sharpness.Name = "CheckBox_Sharpness"
        Me.CheckBox_Sharpness.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Sharpness.TabIndex = 127
        Me.CheckBox_Sharpness.TabStop = False
        Me.CheckBox_Sharpness.UseVisualStyleBackColor = True
        '
        'CheckBox_Zoom
        '
        Me.CheckBox_Zoom.AutoSize = True
        Me.CheckBox_Zoom.Location = New System.Drawing.Point(57, 394)
        Me.CheckBox_Zoom.Name = "CheckBox_Zoom"
        Me.CheckBox_Zoom.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Zoom.TabIndex = 128
        Me.CheckBox_Zoom.TabStop = False
        Me.CheckBox_Zoom.UseVisualStyleBackColor = True
        '
        'CheckBox_Pan
        '
        Me.CheckBox_Pan.AutoSize = True
        Me.CheckBox_Pan.Location = New System.Drawing.Point(57, 421)
        Me.CheckBox_Pan.Name = "CheckBox_Pan"
        Me.CheckBox_Pan.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Pan.TabIndex = 129
        Me.CheckBox_Pan.TabStop = False
        Me.CheckBox_Pan.UseVisualStyleBackColor = True
        '
        'CheckBox_Tilt
        '
        Me.CheckBox_Tilt.AutoSize = True
        Me.CheckBox_Tilt.Location = New System.Drawing.Point(57, 447)
        Me.CheckBox_Tilt.Name = "CheckBox_Tilt"
        Me.CheckBox_Tilt.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Tilt.TabIndex = 130
        Me.CheckBox_Tilt.TabStop = False
        Me.CheckBox_Tilt.UseVisualStyleBackColor = True
        '
        'ComboBox_VideoFormat
        '
        Me.ComboBox_VideoFormat.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_VideoFormat.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoFormat.BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoFormat.BackColor_Focused = System.Drawing.Color.Transparent
        Me.ComboBox_VideoFormat.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoFormat.BorderColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoFormat.BorderSize = 1
        Me.ComboBox_VideoFormat.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_VideoFormat.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoFormat.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoFormat.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoFormat.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoFormat.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoFormat.DropDownHeight = 318
        Me.ComboBox_VideoFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_VideoFormat.DropDownWidth = 80
        Me.ComboBox_VideoFormat.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_VideoFormat.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_VideoFormat.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_VideoFormat.IntegralHeight = False
        Me.ComboBox_VideoFormat.Location = New System.Drawing.Point(11, 60)
        Me.ComboBox_VideoFormat.Name = "ComboBox_VideoFormat"
        Me.ComboBox_VideoFormat.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_VideoFormat.Size = New System.Drawing.Size(70, 22)
        Me.ComboBox_VideoFormat.TabIndex = 131
        Me.ComboBox_VideoFormat.TabStop = False
        '
        'ComboBox_VideoSize
        '
        Me.ComboBox_VideoSize.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_VideoSize.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoSize.BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoSize.BackColor_Focused = System.Drawing.Color.Transparent
        Me.ComboBox_VideoSize.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoSize.BorderColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoSize.BorderSize = 1
        Me.ComboBox_VideoSize.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_VideoSize.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoSize.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoSize.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoSize.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoSize.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoSize.DropDownHeight = 318
        Me.ComboBox_VideoSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_VideoSize.DropDownWidth = 80
        Me.ComboBox_VideoSize.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_VideoSize.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_VideoSize.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_VideoSize.IntegralHeight = False
        Me.ComboBox_VideoSize.Location = New System.Drawing.Point(88, 60)
        Me.ComboBox_VideoSize.Name = "ComboBox_VideoSize"
        Me.ComboBox_VideoSize.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_VideoSize.Size = New System.Drawing.Size(96, 22)
        Me.ComboBox_VideoSize.TabIndex = 132
        Me.ComboBox_VideoSize.TabStop = False
        '
        'ComboBox_VideoFPS
        '
        Me.ComboBox_VideoFPS.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_VideoFPS.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoFPS.BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoFPS.BackColor_Focused = System.Drawing.Color.Transparent
        Me.ComboBox_VideoFPS.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoFPS.BorderColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoFPS.BorderSize = 1
        Me.ComboBox_VideoFPS.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_VideoFPS.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoFPS.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoFPS.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoFPS.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoFPS.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoFPS.DropDownHeight = 318
        Me.ComboBox_VideoFPS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_VideoFPS.DropDownWidth = 80
        Me.ComboBox_VideoFPS.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_VideoFPS.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_VideoFPS.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_VideoFPS.IntegralHeight = False
        Me.ComboBox_VideoFPS.Location = New System.Drawing.Point(191, 60)
        Me.ComboBox_VideoFPS.Name = "ComboBox_VideoFPS"
        Me.ComboBox_VideoFPS.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_VideoFPS.Size = New System.Drawing.Size(60, 22)
        Me.ComboBox_VideoFPS.TabIndex = 133
        Me.ComboBox_VideoFPS.TabStop = False
        '
        'Label_Compression
        '
        Me.Label_Compression.AutoSize = True
        Me.Label_Compression.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Compression.Location = New System.Drawing.Point(9, 44)
        Me.Label_Compression.Name = "Label_Compression"
        Me.Label_Compression.Size = New System.Drawing.Size(68, 13)
        Me.Label_Compression.TabIndex = 134
        Me.Label_Compression.Text = "Compression"
        '
        'Label_VideoSize
        '
        Me.Label_VideoSize.AutoSize = True
        Me.Label_VideoSize.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_VideoSize.Location = New System.Drawing.Point(89, 44)
        Me.Label_VideoSize.Name = "Label_VideoSize"
        Me.Label_VideoSize.Size = New System.Drawing.Size(54, 13)
        Me.Label_VideoSize.TabIndex = 135
        Me.Label_VideoSize.Text = "Video size"
        '
        'Label_MaxFps
        '
        Me.Label_MaxFps.AutoSize = True
        Me.Label_MaxFps.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MaxFps.Location = New System.Drawing.Point(193, 44)
        Me.Label_MaxFps.Name = "Label_MaxFps"
        Me.Label_MaxFps.Size = New System.Drawing.Size(48, 13)
        Me.Label_MaxFps.TabIndex = 136
        Me.Label_MaxFps.Text = "Max FPS"
        '
        'btn_DefaultAll
        '
        Me.btn_DefaultAll.BorderShow = False
        DesignerRectTracker25.IsActive = False
        DesignerRectTracker25.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker25.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_DefaultAll.CenterPtTracker = DesignerRectTracker25
        CBlendItems25.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems25.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_DefaultAll.ColorFillBlend = CBlendItems25
        CBlendItems26.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems26.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_DefaultAll.ColorFillBlendChecked = CBlendItems26
        Me.btn_DefaultAll.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.btn_DefaultAll.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_DefaultAll.Corners.All = CType(-1, Short)
        Me.btn_DefaultAll.Corners.LowerLeft = CType(3, Short)
        Me.btn_DefaultAll.Corners.LowerRight = CType(11, Short)
        Me.btn_DefaultAll.Corners.UpperLeft = CType(3, Short)
        Me.btn_DefaultAll.Corners.UpperRight = CType(11, Short)
        Me.btn_DefaultAll.DimFactorOver = -40
        Me.btn_DefaultAll.FillType = MyButton.eFillType.Solid
        Me.btn_DefaultAll.FillTypeChecked = MyButton.eFillType.Solid
        Me.btn_DefaultAll.FocalPoints.CenterPtX = 0.0!
        Me.btn_DefaultAll.FocalPoints.CenterPtY = 0.40625!
        Me.btn_DefaultAll.FocalPoints.FocusPtX = 0.0!
        Me.btn_DefaultAll.FocalPoints.FocusPtY = 0.0!
        Me.btn_DefaultAll.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_DefaultAll.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_DefaultAll.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_DefaultAll.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker26.IsActive = False
        DesignerRectTracker26.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker26.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_DefaultAll.FocusPtTracker = DesignerRectTracker26
        Me.btn_DefaultAll.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_DefaultAll.Image = Nothing
        Me.btn_DefaultAll.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_DefaultAll.ImageIndex = 0
        Me.btn_DefaultAll.ImageSize = New System.Drawing.Size(31, 31)
        Me.btn_DefaultAll.Location = New System.Drawing.Point(7, 535)
        Me.btn_DefaultAll.Name = "btn_DefaultAll"
        Me.btn_DefaultAll.Shape = MyButton.eShape.Rectangle
        Me.btn_DefaultAll.SideImage = CType(resources.GetObject("btn_DefaultAll.SideImage"), System.Drawing.Image)
        Me.btn_DefaultAll.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_DefaultAll.SideImageSize = New System.Drawing.Size(30, 26)
        Me.btn_DefaultAll.Size = New System.Drawing.Size(118, 26)
        Me.btn_DefaultAll.TabIndex = 137
        Me.btn_DefaultAll.TabStop = False
        Me.btn_DefaultAll.Text = "Default for all"
        Me.btn_DefaultAll.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_DefaultAll.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_DefaultAll.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_DefaultAll.TextShadow = System.Drawing.Color.Transparent
        '
        'TrackBar_Focus
        '
        Me.TrackBar_Focus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Focus.AutoSize = False
        Me.TrackBar_Focus.Location = New System.Drawing.Point(72, 492)
        Me.TrackBar_Focus.Maximum = 255
        Me.TrackBar_Focus.Name = "TrackBar_Focus"
        Me.TrackBar_Focus.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Focus.TabIndex = 15
        Me.TrackBar_Focus.TickFrequency = 20
        Me.TrackBar_Focus.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'CheckBox_Focus
        '
        Me.CheckBox_Focus.AutoSize = True
        Me.CheckBox_Focus.Location = New System.Drawing.Point(57, 505)
        Me.CheckBox_Focus.Name = "CheckBox_Focus"
        Me.CheckBox_Focus.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Focus.TabIndex = 141
        Me.CheckBox_Focus.TabStop = False
        Me.CheckBox_Focus.UseVisualStyleBackColor = True
        '
        'Label_Focus
        '
        Me.Label_Focus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Focus.BackColor = System.Drawing.Color.MintCream
        Me.Label_Focus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Focus.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Focus.Location = New System.Drawing.Point(216, 501)
        Me.Label_Focus.Name = "Label_Focus"
        Me.Label_Focus.Size = New System.Drawing.Size(35, 20)
        Me.Label_Focus.TabIndex = 139
        Me.Label_Focus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CheckBox_Gain
        '
        Me.CheckBox_Gain.AutoSize = True
        Me.CheckBox_Gain.Location = New System.Drawing.Point(57, 142)
        Me.CheckBox_Gain.Name = "CheckBox_Gain"
        Me.CheckBox_Gain.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_Gain.TabIndex = 153
        Me.CheckBox_Gain.TabStop = False
        Me.CheckBox_Gain.UseVisualStyleBackColor = True
        '
        'MyButton_Gain
        '
        Me.MyButton_Gain.BorderShow = False
        DesignerRectTracker27.IsActive = False
        DesignerRectTracker27.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker27.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Gain.CenterPtTracker = DesignerRectTracker27
        CBlendItems27.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems27.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Gain.ColorFillBlend = CBlendItems27
        CBlendItems28.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems28.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Gain.ColorFillBlendChecked = CBlendItems28
        Me.MyButton_Gain.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Gain.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Gain.Corners.All = CType(-1, Short)
        Me.MyButton_Gain.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Gain.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Gain.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Gain.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Gain.DimFactorOver = -40
        Me.MyButton_Gain.FillType = MyButton.eFillType.Solid
        Me.MyButton_Gain.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Gain.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Gain.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Gain.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Gain.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Gain.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Gain.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Gain.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Gain.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker28.IsActive = False
        DesignerRectTracker28.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker28.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Gain.FocusPtTracker = DesignerRectTracker28
        Me.MyButton_Gain.Image = Nothing
        Me.MyButton_Gain.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Gain.ImageIndex = 0
        Me.MyButton_Gain.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Gain.Location = New System.Drawing.Point(7, 136)
        Me.MyButton_Gain.Name = "MyButton_Gain"
        Me.MyButton_Gain.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Gain.SideImage = CType(resources.GetObject("MyButton_Gain.SideImage"), System.Drawing.Image)
        Me.MyButton_Gain.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Gain.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Gain.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Gain.TabIndex = 152
        Me.MyButton_Gain.TabStop = False
        Me.MyButton_Gain.Text = ""
        Me.MyButton_Gain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Gain.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Gain.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Gain.TextShadow = System.Drawing.Color.Transparent
        '
        'Label_Gain
        '
        Me.Label_Gain.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Gain.BackColor = System.Drawing.Color.MintCream
        Me.Label_Gain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Gain.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Gain.Location = New System.Drawing.Point(216, 138)
        Me.Label_Gain.Name = "Label_Gain"
        Me.Label_Gain.Size = New System.Drawing.Size(35, 20)
        Me.Label_Gain.TabIndex = 151
        Me.Label_Gain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_BackLight
        '
        Me.TrackBar_BackLight.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_BackLight.AutoSize = False
        Me.TrackBar_BackLight.Location = New System.Drawing.Point(72, 237)
        Me.TrackBar_BackLight.Maximum = 255
        Me.TrackBar_BackLight.Name = "TrackBar_BackLight"
        Me.TrackBar_BackLight.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_BackLight.TabIndex = 6
        Me.TrackBar_BackLight.TickFrequency = 20
        Me.TrackBar_BackLight.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'TrackBar_ColorEnable
        '
        Me.TrackBar_ColorEnable.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_ColorEnable.AutoSize = False
        Me.TrackBar_ColorEnable.Location = New System.Drawing.Point(72, 348)
        Me.TrackBar_ColorEnable.Maximum = 255
        Me.TrackBar_ColorEnable.Name = "TrackBar_ColorEnable"
        Me.TrackBar_ColorEnable.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_ColorEnable.TabIndex = 10
        Me.TrackBar_ColorEnable.TickFrequency = 20
        Me.TrackBar_ColorEnable.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'CheckBox_ColorEnable
        '
        Me.CheckBox_ColorEnable.AutoSize = True
        Me.CheckBox_ColorEnable.Location = New System.Drawing.Point(57, 361)
        Me.CheckBox_ColorEnable.Name = "CheckBox_ColorEnable"
        Me.CheckBox_ColorEnable.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_ColorEnable.TabIndex = 149
        Me.CheckBox_ColorEnable.TabStop = False
        Me.CheckBox_ColorEnable.UseVisualStyleBackColor = True
        '
        'CheckBox_BackLight
        '
        Me.CheckBox_BackLight.AutoSize = True
        Me.CheckBox_BackLight.Location = New System.Drawing.Point(57, 251)
        Me.CheckBox_BackLight.Name = "CheckBox_BackLight"
        Me.CheckBox_BackLight.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox_BackLight.TabIndex = 148
        Me.CheckBox_BackLight.TabStop = False
        Me.CheckBox_BackLight.UseVisualStyleBackColor = True
        '
        'MyButton_ColorEnable
        '
        Me.MyButton_ColorEnable.BorderShow = False
        DesignerRectTracker29.IsActive = False
        DesignerRectTracker29.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker29.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_ColorEnable.CenterPtTracker = DesignerRectTracker29
        CBlendItems29.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems29.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_ColorEnable.ColorFillBlend = CBlendItems29
        CBlendItems30.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems30.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_ColorEnable.ColorFillBlendChecked = CBlendItems30
        Me.MyButton_ColorEnable.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_ColorEnable.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_ColorEnable.Corners.All = CType(-1, Short)
        Me.MyButton_ColorEnable.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_ColorEnable.Corners.LowerRight = CType(11, Short)
        Me.MyButton_ColorEnable.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_ColorEnable.Corners.UpperRight = CType(11, Short)
        Me.MyButton_ColorEnable.DimFactorOver = -40
        Me.MyButton_ColorEnable.FillType = MyButton.eFillType.Solid
        Me.MyButton_ColorEnable.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_ColorEnable.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_ColorEnable.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_ColorEnable.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_ColorEnable.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_ColorEnable.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_ColorEnable.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_ColorEnable.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_ColorEnable.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker30.IsActive = False
        DesignerRectTracker30.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker30.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_ColorEnable.FocusPtTracker = DesignerRectTracker30
        Me.MyButton_ColorEnable.Image = Nothing
        Me.MyButton_ColorEnable.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_ColorEnable.ImageIndex = 0
        Me.MyButton_ColorEnable.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_ColorEnable.Location = New System.Drawing.Point(7, 355)
        Me.MyButton_ColorEnable.Name = "MyButton_ColorEnable"
        Me.MyButton_ColorEnable.Shape = MyButton.eShape.Rectangle
        Me.MyButton_ColorEnable.SideImage = CType(resources.GetObject("MyButton_ColorEnable.SideImage"), System.Drawing.Image)
        Me.MyButton_ColorEnable.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_ColorEnable.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_ColorEnable.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_ColorEnable.TabIndex = 147
        Me.MyButton_ColorEnable.TabStop = False
        Me.MyButton_ColorEnable.Text = ""
        Me.MyButton_ColorEnable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_ColorEnable.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_ColorEnable.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_ColorEnable.TextShadow = System.Drawing.Color.Transparent
        '
        'MyButton_BackLight
        '
        Me.MyButton_BackLight.BorderShow = False
        DesignerRectTracker31.IsActive = False
        DesignerRectTracker31.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker31.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_BackLight.CenterPtTracker = DesignerRectTracker31
        CBlendItems31.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems31.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_BackLight.ColorFillBlend = CBlendItems31
        CBlendItems32.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems32.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_BackLight.ColorFillBlendChecked = CBlendItems32
        Me.MyButton_BackLight.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_BackLight.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_BackLight.Corners.All = CType(-1, Short)
        Me.MyButton_BackLight.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_BackLight.Corners.LowerRight = CType(11, Short)
        Me.MyButton_BackLight.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_BackLight.Corners.UpperRight = CType(11, Short)
        Me.MyButton_BackLight.DimFactorOver = -40
        Me.MyButton_BackLight.FillType = MyButton.eFillType.Solid
        Me.MyButton_BackLight.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_BackLight.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_BackLight.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_BackLight.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_BackLight.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_BackLight.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_BackLight.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_BackLight.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_BackLight.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker32.IsActive = True
        DesignerRectTracker32.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker32.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_BackLight.FocusPtTracker = DesignerRectTracker32
        Me.MyButton_BackLight.Image = Nothing
        Me.MyButton_BackLight.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_BackLight.ImageIndex = 0
        Me.MyButton_BackLight.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_BackLight.Location = New System.Drawing.Point(7, 244)
        Me.MyButton_BackLight.Name = "MyButton_BackLight"
        Me.MyButton_BackLight.Shape = MyButton.eShape.Rectangle
        Me.MyButton_BackLight.SideImage = CType(resources.GetObject("MyButton_BackLight.SideImage"), System.Drawing.Image)
        Me.MyButton_BackLight.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_BackLight.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_BackLight.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_BackLight.TabIndex = 146
        Me.MyButton_BackLight.TabStop = False
        Me.MyButton_BackLight.Text = ""
        Me.MyButton_BackLight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_BackLight.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_BackLight.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_BackLight.TextShadow = System.Drawing.Color.Transparent
        '
        'Label_ColorEnable
        '
        Me.Label_ColorEnable.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_ColorEnable.BackColor = System.Drawing.Color.MintCream
        Me.Label_ColorEnable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_ColorEnable.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ColorEnable.Location = New System.Drawing.Point(216, 357)
        Me.Label_ColorEnable.Name = "Label_ColorEnable"
        Me.Label_ColorEnable.Size = New System.Drawing.Size(35, 20)
        Me.Label_ColorEnable.TabIndex = 145
        Me.Label_ColorEnable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_BackLight
        '
        Me.Label_BackLight.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_BackLight.BackColor = System.Drawing.Color.MintCream
        Me.Label_BackLight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_BackLight.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_BackLight.Location = New System.Drawing.Point(216, 246)
        Me.Label_BackLight.Name = "Label_BackLight"
        Me.Label_BackLight.Size = New System.Drawing.Size(35, 20)
        Me.Label_BackLight.TabIndex = 143
        Me.Label_BackLight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TrackBar_Gain
        '
        Me.TrackBar_Gain.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TrackBar_Gain.AutoSize = False
        Me.TrackBar_Gain.Location = New System.Drawing.Point(72, 129)
        Me.TrackBar_Gain.Maximum = 255
        Me.TrackBar_Gain.Name = "TrackBar_Gain"
        Me.TrackBar_Gain.Size = New System.Drawing.Size(143, 32)
        Me.TrackBar_Gain.TabIndex = 2
        Me.TrackBar_Gain.TickFrequency = 20
        Me.TrackBar_Gain.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'MyButton_Focus
        '
        Me.MyButton_Focus.BorderShow = False
        DesignerRectTracker33.IsActive = False
        DesignerRectTracker33.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker33.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Focus.CenterPtTracker = DesignerRectTracker33
        CBlendItems33.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems33.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.MyButton_Focus.ColorFillBlend = CBlendItems33
        CBlendItems34.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems34.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.MyButton_Focus.ColorFillBlendChecked = CBlendItems34
        Me.MyButton_Focus.ColorFillSolid = System.Drawing.Color.Cornsilk
        Me.MyButton_Focus.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.MyButton_Focus.Corners.All = CType(-1, Short)
        Me.MyButton_Focus.Corners.LowerLeft = CType(3, Short)
        Me.MyButton_Focus.Corners.LowerRight = CType(11, Short)
        Me.MyButton_Focus.Corners.UpperLeft = CType(3, Short)
        Me.MyButton_Focus.Corners.UpperRight = CType(11, Short)
        Me.MyButton_Focus.DimFactorOver = -40
        Me.MyButton_Focus.FillType = MyButton.eFillType.Solid
        Me.MyButton_Focus.FillTypeChecked = MyButton.eFillType.Solid
        Me.MyButton_Focus.FocalPoints.CenterPtX = 0.0!
        Me.MyButton_Focus.FocalPoints.CenterPtY = 0.40625!
        Me.MyButton_Focus.FocalPoints.FocusPtX = 0.0!
        Me.MyButton_Focus.FocalPoints.FocusPtY = 0.0!
        Me.MyButton_Focus.FocalPointsChecked.CenterPtX = 0.5!
        Me.MyButton_Focus.FocalPointsChecked.CenterPtY = 0.5!
        Me.MyButton_Focus.FocalPointsChecked.FocusPtX = 0.0!
        Me.MyButton_Focus.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker34.IsActive = False
        DesignerRectTracker34.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker34.TrackerRectangle"), System.Drawing.RectangleF)
        Me.MyButton_Focus.FocusPtTracker = DesignerRectTracker34
        Me.MyButton_Focus.Image = Nothing
        Me.MyButton_Focus.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MyButton_Focus.ImageIndex = 0
        Me.MyButton_Focus.ImageSize = New System.Drawing.Size(31, 31)
        Me.MyButton_Focus.Location = New System.Drawing.Point(7, 500)
        Me.MyButton_Focus.Name = "MyButton_Focus"
        Me.MyButton_Focus.Shape = MyButton.eShape.Rectangle
        Me.MyButton_Focus.SideImage = CType(resources.GetObject("MyButton_Focus.SideImage"), System.Drawing.Image)
        Me.MyButton_Focus.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MyButton_Focus.SideImageSize = New System.Drawing.Size(30, 26)
        Me.MyButton_Focus.Size = New System.Drawing.Size(46, 26)
        Me.MyButton_Focus.TabIndex = 154
        Me.MyButton_Focus.TabStop = False
        Me.MyButton_Focus.Text = ""
        Me.MyButton_Focus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MyButton_Focus.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.MyButton_Focus.TextMargin = New System.Windows.Forms.Padding(0)
        Me.MyButton_Focus.TextShadow = System.Drawing.Color.Transparent
        '
        'Form_VideoInControls
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(261, 568)
        Me.ControlBox = False
        Me.Controls.Add(Me.TrackBar_Exposure)
        Me.Controls.Add(Me.TrackBar_Gain)
        Me.Controls.Add(Me.MyButton_Focus)
        Me.Controls.Add(Me.CheckBox_Gain)
        Me.Controls.Add(Me.MyButton_Gain)
        Me.Controls.Add(Me.Label_Gain)
        Me.Controls.Add(Me.CheckBox_ColorEnable)
        Me.Controls.Add(Me.CheckBox_BackLight)
        Me.Controls.Add(Me.MyButton_ColorEnable)
        Me.Controls.Add(Me.MyButton_BackLight)
        Me.Controls.Add(Me.Label_ColorEnable)
        Me.Controls.Add(Me.Label_BackLight)
        Me.Controls.Add(Me.CheckBox_Focus)
        Me.Controls.Add(Me.Label_Focus)
        Me.Controls.Add(Me.TrackBar_Brightness)
        Me.Controls.Add(Me.TrackBar_Contrast)
        Me.Controls.Add(Me.TrackBar_Gamma)
        Me.Controls.Add(Me.TrackBar_Saturation)
        Me.Controls.Add(Me.TrackBar_WhiteBalance)
        Me.Controls.Add(Me.TrackBar_Hue)
        Me.Controls.Add(Me.TrackBar_Sharpness)
        Me.Controls.Add(Me.TrackBar_Zoom)
        Me.Controls.Add(Me.TrackBar_Pan)
        Me.Controls.Add(Me.TrackBar_Tilt)
        Me.Controls.Add(Me.btn_DefaultAll)
        Me.Controls.Add(Me.Label_MaxFps)
        Me.Controls.Add(Me.Label_VideoSize)
        Me.Controls.Add(Me.Label_Compression)
        Me.Controls.Add(Me.ComboBox_VideoFPS)
        Me.Controls.Add(Me.ComboBox_VideoSize)
        Me.Controls.Add(Me.ComboBox_VideoFormat)
        Me.Controls.Add(Me.CheckBox_Tilt)
        Me.Controls.Add(Me.CheckBox_Pan)
        Me.Controls.Add(Me.CheckBox_Zoom)
        Me.Controls.Add(Me.CheckBox_Sharpness)
        Me.Controls.Add(Me.CheckBox_Hue)
        Me.Controls.Add(Me.CheckBox_WhiteBalance)
        Me.Controls.Add(Me.CheckBox_Saturation)
        Me.Controls.Add(Me.CheckBox_Gamma)
        Me.Controls.Add(Me.CheckBox_Contrast)
        Me.Controls.Add(Me.CheckBox_Brightness)
        Me.Controls.Add(Me.Label_Auto)
        Me.Controls.Add(Me.CheckBox_Exposure)
        Me.Controls.Add(Me.Label_Default)
        Me.Controls.Add(Me.MyButton_Tilt)
        Me.Controls.Add(Me.MyButton_Pan)
        Me.Controls.Add(Me.MyButton_Zoom)
        Me.Controls.Add(Me.MyButton_Sharpness)
        Me.Controls.Add(Me.MyButton_Hue)
        Me.Controls.Add(Me.MyButton_WhiteBalance)
        Me.Controls.Add(Me.MyButton_Saturation)
        Me.Controls.Add(Me.MyButton_Gamma)
        Me.Controls.Add(Me.MyButton_Contrast)
        Me.Controls.Add(Me.Label_Hue)
        Me.Controls.Add(Me.Label_Tilt)
        Me.Controls.Add(Me.Label_Pan)
        Me.Controls.Add(Me.Label_Zoom)
        Me.Controls.Add(Me.Label_Sharpness)
        Me.Controls.Add(Me.Label_Exposure)
        Me.Controls.Add(Me.Label_WhiteBalance)
        Me.Controls.Add(Me.Label_Gamma)
        Me.Controls.Add(Me.Label_Saturation)
        Me.Controls.Add(Me.Label_Contrast)
        Me.Controls.Add(Me.Label_Brightness)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.btn_Close)
        Me.Controls.Add(Me.MyButton_Exposure)
        Me.Controls.Add(Me.MyButton_Brightness)
        Me.Controls.Add(Me.TrackBar_Focus)
        Me.Controls.Add(Me.TrackBar_BackLight)
        Me.Controls.Add(Me.TrackBar_ColorEnable)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form_VideoInControls"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Video Input Controls"
        CType(Me.TrackBar_Brightness, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.TrackBar_Contrast, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Gamma, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Exposure, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_WhiteBalance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Saturation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Sharpness, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Zoom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Pan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Tilt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Hue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Focus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_BackLight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_ColorEnable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Gain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_Close As MyButton
    Friend WithEvents TrackBar_Brightness As System.Windows.Forms.TrackBar
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents Tool_OpenSourcePanel As System.Windows.Forms.ToolStripButton
    Friend WithEvents Tool_OpenFormatPanel As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TrackBar_Contrast As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar_Gamma As System.Windows.Forms.TrackBar
    Friend WithEvents Label_Brightness As System.Windows.Forms.Label
    Friend WithEvents Label_Contrast As System.Windows.Forms.Label
    Friend WithEvents Label_Saturation As System.Windows.Forms.Label
    Friend WithEvents Label_Exposure As System.Windows.Forms.Label
    Friend WithEvents Label_WhiteBalance As System.Windows.Forms.Label
    Friend WithEvents Label_Gamma As System.Windows.Forms.Label
    Friend WithEvents TrackBar_Exposure As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar_WhiteBalance As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar_Saturation As System.Windows.Forms.TrackBar
    Friend WithEvents Label_Sharpness As System.Windows.Forms.Label
    Friend WithEvents TrackBar_Sharpness As System.Windows.Forms.TrackBar
    Friend WithEvents Label_Zoom As System.Windows.Forms.Label
    Friend WithEvents TrackBar_Zoom As System.Windows.Forms.TrackBar
    Friend WithEvents Label_Pan As System.Windows.Forms.Label
    Friend WithEvents TrackBar_Pan As System.Windows.Forms.TrackBar
    Friend WithEvents Label_Tilt As System.Windows.Forms.Label
    Friend WithEvents TrackBar_Tilt As System.Windows.Forms.TrackBar
    Friend WithEvents Label_Hue As System.Windows.Forms.Label
    Friend WithEvents TrackBar_Hue As System.Windows.Forms.TrackBar
    Friend WithEvents MyButton_Exposure As MyButton
    Friend WithEvents MyButton_Brightness As MyButton
    Friend WithEvents MyButton_Contrast As MyButton
    Friend WithEvents MyButton_Gamma As MyButton
    Friend WithEvents MyButton_Saturation As MyButton
    Friend WithEvents MyButton_WhiteBalance As MyButton
    Friend WithEvents MyButton_Hue As MyButton
    Friend WithEvents MyButton_Sharpness As MyButton
    Friend WithEvents MyButton_Zoom As MyButton
    Friend WithEvents MyButton_Pan As MyButton
    Friend WithEvents MyButton_Tilt As MyButton
    Friend WithEvents Label_Default As System.Windows.Forms.Label
    Friend WithEvents CheckBox_Exposure As System.Windows.Forms.CheckBox
    Friend WithEvents Label_Auto As System.Windows.Forms.Label
    Friend WithEvents CheckBox_Brightness As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Contrast As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Gamma As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Saturation As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_WhiteBalance As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Hue As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Sharpness As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Zoom As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Pan As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Tilt As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBox_VideoFormat As MyComboBox
    Friend WithEvents ComboBox_VideoSize As MyComboBox
    Friend WithEvents ComboBox_VideoFPS As MyComboBox
    Friend WithEvents Label_Compression As System.Windows.Forms.Label
    Friend WithEvents Label_VideoSize As System.Windows.Forms.Label
    Friend WithEvents Label_MaxFps As System.Windows.Forms.Label
    Friend WithEvents btn_DefaultAll As MyButton
    Friend WithEvents TrackBar_Focus As System.Windows.Forms.TrackBar
    Friend WithEvents CheckBox_Focus As System.Windows.Forms.CheckBox
    Friend WithEvents Label_Focus As System.Windows.Forms.Label
    Friend WithEvents CheckBox_Gain As System.Windows.Forms.CheckBox
    Friend WithEvents MyButton_Gain As MyButton
    Friend WithEvents Label_Gain As System.Windows.Forms.Label
    Friend WithEvents TrackBar_BackLight As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar_ColorEnable As System.Windows.Forms.TrackBar
    Friend WithEvents CheckBox_ColorEnable As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_BackLight As System.Windows.Forms.CheckBox
    Friend WithEvents MyButton_ColorEnable As MyButton
    Friend WithEvents MyButton_BackLight As MyButton
    Friend WithEvents Label_ColorEnable As System.Windows.Forms.Label
    Friend WithEvents Label_BackLight As System.Windows.Forms.Label
    Friend WithEvents TrackBar_Gain As System.Windows.Forms.TrackBar
    Friend WithEvents MyButton_Focus As MyButton
End Class
